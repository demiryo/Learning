//This is hello world, By Omar Demiry

//Include the iostream libreary 
#include <iostream>  

//enter the standered namespace for ease 
using namespace std;

void main()
{

	//Print txt to screen
	cout 
		<< endl // new line to "pretty type" the code
		<< "Hello new world!"<<endl
		<< "this is Omar's first C++ program! =)" << endl 
		<< endl;
	//to keep txt on screen
	system("PAUSE");
}